import React from 'react'
import {BrowserRouter as Router, Route, Link, Routes,NavLink, useNavigate} from 'react-router-dom';
import {Row, Navbar, Container, Nav } from "react-bootstrap";


function Header() {

  return (
    <>
        <header>
<Navbar bg="light" expand="lg">

        <Container>
        <Row>
        
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="navbarScroll" className='menu'>
          <Nav
        
          className="me-auto my-2 my-lg-0">
         
         
          <>
               <Nav.Item>
                <Nav.Link as={Link}  to={"/Home"}>Home</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link as={Link}  to={"/User"}> User</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link as={Link}  to={"/Login"}> Login</Nav.Link>
              </Nav.Item>
          </>

         

             
            </Nav>
          
           
          </Navbar.Collapse>
         
        </Row>
          
            
        </Container>
      </Navbar>
</header>

    </>
  )
}

export default Header