function show(){
    console.log("show");
  };

  function news(){
     console.log("show 2");
  }
  news()

  show()