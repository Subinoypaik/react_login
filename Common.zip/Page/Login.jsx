import axios from "axios";
import React, { useState, useEffect } from "react";
import { Col, Container, Form, Row } from "react-bootstrap";
import {useNavigate} from 'react-router-dom'
function Login(){
  var navigate=useNavigate()
     let [email,setemail]= useState();
     let [password,setpassword]= useState()

 const handelemail = (e)=>{
  setemail(e.target.value)
  console.log(e.target.value);
 }

 const handelpassword = (e)=>{
  setpassword(e.target.value)
  console.log(e.target.value);
 }


 const submit = (e)=>{
     console.log(email,password);
     e.preventDefault();
     axios.post("https://reqres.in/api/login",{
            email:email,
            password:password
      })
      .then((result)=>{
           console.log(result.data);
           //localStorage.setItem("token");
           navigate('/Home')
           alert("success")
      }).catch((err)=>{
           console.log(err);
      })
 }


     return(
        <>

          

               <Container>
                  <Row>
                      <Col   sm={6} lg={6} className="m-auto mt-5">
                      <h1>Login</h1>
                 
              <Form.Group className="mb-3">
                <Form.Label htmlFor="email"> Email </Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter email"
                    name="email"
                    onChange={handelemail}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label htmlFor="password">password </Form.Label>
                <Form.Control
                  type="password"
                  placeholder="password"
                  name="password"
                  onChange={handelpassword}
                />
              </Form.Group>

            
              <button type="submit" className="btn btn-success w-100"  onClick={submit}>Login</button>
             

            
          
                      </Col>
          
                  </Row>
               </Container>
        </>
     )
}

export default Login;