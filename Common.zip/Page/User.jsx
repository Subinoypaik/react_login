import React, { useEffect, useState } from "react";
 import axios from "axios";


function User(){
    let [data, setdata] = useState([]);

    let usedta = async()=>{
        const res = await axios.get("https://retoolapi.dev/GFHqAV/getemployees");
        console.log(res.data);
        setdata(res.data)
     }

     useEffect(()=>{
        usedta()
     },[])
    return(
                    
        <>
        {
            data.map((post) => {
                const {id, name}= post;
                  return(
                       <>
                         <div key={id}>
                          <h3>{id}  {name}</h3>

                         
                         </div>
                        
                       </>
                   
                  )
            })
        }
    </>
    )
     
    
}

export default User;