import React, { useEffect, useState } from "react";
import { Container, Row, Col,Button } from "react-bootstrap";
import axios from "axios";
import { Link } from "react-router-dom";

function Home() {
  const [getapi,  setfood] = useState([]);

  const employees = async () => {
    const res = await axios.get("https://retoolapi.dev/GFHqAV/getemployees");
    // console.log(res.data);
    setfood(res.data);
  };
  useEffect(() => {
    employees();
  }, []);

  const mystyle = {
    border: "1px solid #e1dedeb0",
    padding: "10px",
    margin:"0 0 30px 0",
    minHeight: "200px"
  };
  const newstyle = {
    marginRight:"10px"
  }


  
  return (
    <>
      <section className="project">
        <Container>
          <div className="background">
            <Row>
              {getapi.map((post) => {
                const { id, name, company, designation, company_logo } = post;
                return (
                  <Col sm={6} lg={3} key={id}>
                    <div className="box" style={mystyle}>
                     <div className="box-flex  d-flex">
                     <div className="headingpart"  style={newstyle}>
                        <h6>{name}</h6>
                        <h3>{company}</h3>
                        <p>{designation}</p>
                      </div>
                      <div className="img-part">
                     
                        <img src={company_logo} alt="img"  className="w-70"/>
                      </div>
                     </div>
                      <div className="viewmore">   <Link to={`/Details/${id}`} className="btn btn-primary"  color="secondary" >View Details</Link></div>
                    </div>
                  </Col>
                );
              })}
            </Row>
          </div>
        </Container>
      </section>
    </>
  );
}

export default Home;
