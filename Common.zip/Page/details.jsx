import React from 'react'

const Details = () => {


 

  return (
    <>
       details

    </>
  )
}

export default Details